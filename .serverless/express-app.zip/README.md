## Backend Codes

- server.js - Run server

- locationController.js - Functions for controller

- locationModel.js - Schema structure for Location model

- api-routes.js - Declaration of routes for contollers in locationController.js

### Image in Docker Hub 

If you wish to view / pull the Docker Image, click [Here](https://hub.docker.com/r/tofuking209/ec2-app) 